<template>
	<f7-page>
		<p style="color:#000000;margin:16px 24px 5px 18px;font-size:32px;font-weight:bold">
			<a href="/home" class="link icon-only" style="color: #000000;height:43px;margin-right:10px"><f7-icon f7="chevron_left"></f7-icon></a>
			Notifications
		</p>
	</f7-page>
</template>

<script>
export default{
	
};
</script>

<style scoped>
.lineclampin{
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    white-space: nowrap !important;
    width: 100% !important;
}
.f7-icons{
	font-size:32px !important;
}
</style>